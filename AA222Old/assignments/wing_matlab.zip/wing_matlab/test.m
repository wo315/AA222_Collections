% test the call to wing.m

clear all;
format compact;
format long e;

% set the inputs
D = [0.16; 0.06; 0.03; 0.02; 0.02; 0.02];   % tube diameters

% call wing
[tiptwist, u] = wing(D);

u'

tiptwist


