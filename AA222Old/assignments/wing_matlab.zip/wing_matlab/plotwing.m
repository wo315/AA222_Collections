function plotwing(p, conn, dg, node_style, line_style)

npts = 10;

nelem = size(conn,1);

% plot the nodes
for i = 1 : nelem,
    n1 = conn(i,1); % index of node 1
    n2 = conn(i,2); % index of node 2
    x = [p(n1,1), p(n2,1)];
    y = [p(n1,2), p(n2,2)] + [dg(3*(n1-1)+1), dg(3*(n2-1)+1)];
    z = [p(n1,3), p(n2,3)];
    plot3(x, y, z, node_style);
    hold on;   
end

% plot the displacement within element
for i = 1 : nelem,
    n1 = conn(i,1); % index of node 1
    n2 = conn(i,2); % index of node 2
    idof1 = 3*(n1-1)+1;
    idof2 = 3*(n2-1)+1;
    d = zeros(4,1);
    d(1) = dg(idof1);
    d(2) = dg(idof1+2);
    d(3) = dg(idof2);
    d(4) = dg(idof2+2);
    [xx,yy,zz] = cubic(p(n1,:), p(n2,:), d, npts);
    plot3(xx, yy, zz, line_style);
    hold on;   
end

axis('equal');
view(0,90);