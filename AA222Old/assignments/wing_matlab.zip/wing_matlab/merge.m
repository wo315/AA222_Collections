function K = merge(A,B,n,C1,C2)

%   MERGE
%
%   This command merges a square matrix B into a larger matrix A.
%   Both A and B must already exist, and the output matrix K has the
%   same dimensions as A. Note that if the user assigns the output
%   matrix also to A, what is going to happen is that A will return
%   with its original values plus the terms added by the merging of
%   B into it. The MERGE command will also take care of changing
%   orientations of D.O.F.'s, for instance if the convention adopted
%   to generate a particular stiffness matrix is different from what
%   you define in your assignment of the positive direction for a
%   number of D.O.F.'s, you can use the MERGE command to
%   automatically account for that when creating the stiffness
%   matrix for the complete system (see below). Essentially, what we
%   do here is to create lambda matrices that will take care of
%   these rotations before doing the merge. The syntax is:
%                      K = merge(A,B,n,C1,C2)
%   where: A is the "larger" matrix being merged into;
%          B is the "smaller" matrix that is going to be merged into
%            the larger one;
%          n is the dimension of B (note that we are assuming B is
%             square);
%          C1 specifies the rows of A in which respective rows of B
%             should be merged into; if you want to change the
%             orientation of any D.O.F. in the matrix B just define
%             the corresponding row in C1 as the negative of the
%             value you want (in other words, the i-th row of B will
%             be merged into the row of A specified in the i-th row
%             of C1, and if the program finds a negative integer
%             there, the appropriate rotations will be performed
%             before the merge);
%          C2 specifies the colums of A in which respective columns
%             of B should be merged into.
%   Obs: C1 and C2 are vectors, and if you want a symmetric merge
%        there is no harm in specifying0 C2 = C1.

lambda = eye(n);               % Find the lambda matrix.
for i=1:n,
    if C1(i) < 0,
        lambda(i,i) = -1;
        C1(i) = -C1(i);
    end
end

bn = lambda'*B*lambda;       % Create new B matrix.

C2 = abs(C2);                % Make sure all elements of C2 are positive.

kk = A;                      % Calculate merged matrix.
for i=1:n,
    l=C1(i);
    for j=1:n,
        m = C2(j);
        kk(l,m) = kk(l,m) + bn(i,j);
    end
end
K = kk;









