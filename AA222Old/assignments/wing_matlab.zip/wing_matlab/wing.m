function [tiptwist, u] = wing(D)

% Wing structural analysis

% Material properties 
E = 210E+9;         % Young's modulus
nu = 0.29;          % Poisson's ratio
G = E/(2+2*nu);     % Shear modulus

% Wing geometry
halfspan = 9.2;
rootchord = 3.7;
frontsweep = 35;
rearsweep = 22;

nelems = 6;         % number of grid elements

t = 0.005 * ones(nelems,1); % tube thicknesses

% Set node coordinates
ndx = 2;
dx = halfspan / ndx;
inode = 1;
%% Front spar
sweep = frontsweep*pi/180;
for i = 1 : ndx+1,
  p(inode,2) = 0;
  p(inode,3) = dx*(i-1);
  p(inode,1) = p(inode,3) * tan(sweep);
  inode = inode + 1;
end

% Rear spar node coordinates
sweep = rearsweep*pi/180;
for i = 1 : ndx+1,
  p(inode,2) = 0;
  p(inode,3) = dx*(i-1);
  p(inode,1) = rootchord + p(inode,3) * tan(sweep);
  inode = inode +1;
end

% Tube radius
r = D ./ 2;
% Polar moments of inertia
J = (pi/2)*(r.^4-(r-t).^4);
% Second moment of inertia
Iz = (pi/4) * (r.^3 - (r-t).^3);

% Sizes of FEM model
nnodes = 6;   % number of nodes
nelem = 6;    % number of elements
nelemnodes = 2; % number of nodes per element
nnodedof = 3; % number of DOF per node
ndof = nnodedof*nelem; % total number of unconstrainted DOF

% Connectivity
conn = [1 2; 2 3; 4 5; 5 6; 2 5; 3 6]; % element connectivity

% Initialize global stiffness matrix with all DOFs (constrained and
% unconstrainted)
Kg = zeros(ndof,ndof);

% Boundary conditions
nBC = 6;             % number of constrained DOF
BC = zeros(ndof, 1); % vector of boundary condition information
BC(1:3) = 1;         % 1 if DOF is constrained, 0 otherwise
BC(10:12) = 1;

% Initialize reduced stiffness matrix (includes only unconstrained DOFs)    
K = zeros(ndof-nBC, ndof-nBC);

% Assemble the global stiffness matrix using:
% kgrid.m and merge.m
% Build stiffness matrix
for i = 1 : nelem,
    kelem = kgrid(p(conn(i,1),:), p(conn(i,2),:), E, G, J(i), Iz(i));
    vmerge = zeros(6,1);
    vmerge(1:3) = nnodedof*(conn(i,1)-1)+[1;2;3]; % could do loop over nelemnodes
    vmerge(4:6) = nnodedof*(conn(i,2)-1)+[1;2;3];
    Kg = merge(Kg, kelem, 6, vmerge, vmerge);
end

% Apply BCs (reduce stiffness matrix)

i2 = 1;
j2 = 1;
for i = 1 : ndof,
    if BC(i) == 0,
        for j = 1 : ndof,
            if BC(j) == 0,
                K(i2,j2) = Kg(i,j);
                j2 = j2 +1;   
            end
        end
        i2 = i2 + 1;
        j2 = 1;
    end
end

% Set forces
f=zeros(ndof-nBC,1);
f(1) = 10000;
f(4) = 5000;
f(7) = 4000;
f(10) = 1000;

% Solve for the unconstrained displacements
uu = K\f;

% Expand the displacements, to the full vector of displacements
% (i.e., include the zeros from the constrained DOFs)
i2 = 1;
for i = 1 : ndof,
    if BC(i) == 1,
        u(i) = 0;
    else
        u(i) = uu(i2);
        i2 = i2 + 1;
    end
end

% Plot figures
figure(1);
clf;
% Plot undeformed wing
plotwing(p, conn, zeros(ndof,1), 'bo', 'b-')
% Plot displaced wing
plotwing(p, conn, u, 'ro', 'r-')

% Calculate tip twist
tipchord = rootchord+halfspan*(-tan(frontsweep*pi/180)+tan(rearsweep*pi/180));
tiptwist = (u(7)-u(16))/tipchord * 180/pi;


