%
% This function computes the (6x6) stiffness matrix for a grid element in global
% coordinates.
%
% The inputs are:
%   x1, x2: the node coordinates for the given element
%   E, G:   Young's modulus and shear modulus of the material
%   J:      torsional rigidity constant 
%   I:      second moment of area about the local z axis

function k = kgrid(x1, x2, E, G, J, I)

% Length and direction cosines
L = norm(x2-x1);
C = (x2(1)-x1(1))/L;
S = (x2(3)-x1(3))/L;

% Coordinate transformation matrix
T = zeros(6,6);
lam = [1 0 0; 0 C S ; 0 -S C];
T = [lam zeros(3,3); zeros(3,3) lam];

k2 = E*I/L^3;
k3 = G*J/L;

k=zeros(6,6);
k = [12*k2 0  6*L*k2    -12*k2   0  6*L*k2;
    0 k3 0              0 -k3  0;
    6*L*k2 0  4*L^2*k2 -6*L*k2  0   2*L^2*k2;
    -12*k2 0 -6*L*k2     12*k2  0  -6*L*k2;
    0    -k3       0         0 k3   0;
    6*L*k2 0 2*L^2*k2  -6*L*k2  0   4*L^2*k2];

k = T'*k*T;

