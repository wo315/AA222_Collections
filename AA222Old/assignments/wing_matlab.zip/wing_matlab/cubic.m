%
% This function interpolates the y displacement of a grid structure that is
% in the x-z plane.
% 
% The function takes the 3D coordinates of the grid element nodes (x1 and
% x2), as well at the nodal displacements and rotations.
%
% The output arguments are the x, y, z coordinates of the cubic spline for
% the given element.

function [x,y,z] = cubic(p1, p2, d, npts)
L = norm(p2-p1);
s = linspace(0,1,npts);
A = [ 1 0 0 0; 0 L 0 0; -3 -2*L 3 -L; 2 L -2 L ];

c = A*d;

% Horner's rule to evaluate the cubic polynomial
for i = 1:npts,
    y(i) = ((c(4)*s(i)+c(3))*s(i)+c(2))*s(i)+c(1);
end

% x and y coordinates are linearly interpolated.
for i = 1 : npts,
    x(i) = (1-s(i))*p1(1) + s(i)*p2(1);
    z(i) = (1-s(i))*p1(3) + s(i)*p2(3);
    %y(i) = (1-s(i))*(p1(2)+d(1)) + s(i)*(p2(2)+d(3));
end